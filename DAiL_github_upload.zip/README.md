# DAiL — Integrated Agent World Test Build

Local **test/simulation** build combining the DAiL agent world, controlled economy,
double-entry ledger, spending policy, mock payment gateway, audit chain,
allowlisted tools, world ticks, API, Docker setup, and tests.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
uvicorn dail.api:app --reload
```
Open `http://127.0.0.1:8000/docs`.

## Run with Docker
```bash
docker compose up --build
```

**Safety:** no real money moves. Payment providers are mocked. Do not connect
real Stripe/Apple Pay/bank/crypto credentials to this build.
